﻿// (c) Copyright Base75 2014

using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("MultiTags")]
	[Tooltip("Finds a Game Object by Name and/or Tag.")]
	public class FindGameObjectWithMultiTag : FsmStateAction
	{

		[RequiredField]

		[Tooltip("Find a GameObject with this MultiTag.")]
		public FsmString withTag;
		
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the result in a GameObject variable.")]
		public FsmGameObject store;
		
		public override void Reset()
		{

			withTag = "";
			store = null;
		}
		
		public override void OnEnter()
		{
			Finish();
			
			if (withTag.Value != "Untagged")
			{

				store.Value = MultiTags.FindWithMultiTag(withTag.Value);
				return;
			}
			

		}
		
		public override string ErrorCheck()
		{
			if ( string.IsNullOrEmpty(withTag.Value))
			{
				return "Specify Tag";
			}
			
			return null;
		}
		
	}
}