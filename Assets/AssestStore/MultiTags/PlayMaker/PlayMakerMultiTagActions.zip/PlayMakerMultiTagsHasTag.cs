﻿// (c) Copyright Base75 2014

using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("MultiTags")]
	[Tooltip("Checks a Game Object's MultiTag.")]
	public class HasTag : FsmStateAction
	{
		public FsmOwnerDefault gameObject;
		
		public FsmString multiTag;

		public FsmBool hasTag;
		
		public override void Reset()
		{
			gameObject = null;
			multiTag = "";
			hasTag = false;
		}
		
		public override void OnEnter()
		{
			GameObject go = Fsm.GetOwnerDefaultTarget(gameObject);
			
			if (go != null)
				hasTag = go.HasTag(multiTag.Value);
			
			Finish();
		}
	}
}