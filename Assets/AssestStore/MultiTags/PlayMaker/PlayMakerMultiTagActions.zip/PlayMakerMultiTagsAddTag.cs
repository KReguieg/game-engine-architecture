﻿// (c) Copyright Base75 2014

using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("MultiTags")]
	[Tooltip("Sets a Game Object's MultiTag.")]
	public class AddTag : FsmStateAction
	{
		public FsmOwnerDefault gameObject;

		public FsmString multiTag;
		
		public override void Reset()
		{
			gameObject = null;
			multiTag = "";
		}
		
		public override void OnEnter()
		{
			GameObject go = Fsm.GetOwnerDefaultTarget(gameObject);
			
			if (go != null)
				go.AddTag(multiTag.Value);
			
			Finish();
		}
	}
}